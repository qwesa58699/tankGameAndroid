package com.example.myapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;

public class step2 extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.step2);

        EditText macc = findViewById(R.id.maccET1);
        EditText mpwd = findViewById(R.id.mpwdET1);
        EditText mnname = findViewById(R.id.mnnameET2);
        ImageButton mback = findViewById(R.id.mbackIBTN2);
        ImageButton msubmit = findViewById(R.id.msubmitIBTN2);
        RadioButton mmgender = findViewById(R.id.mmaleRB2);
        RadioButton mfmgender = findViewById(R.id.mfmaleRB2);
        mback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(step2.this, step1.class);
                startActivity(intent);
            }
        });

        msubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(step2.this, step1.class);
                startActivity(intent);
            }
        });
    }
}
