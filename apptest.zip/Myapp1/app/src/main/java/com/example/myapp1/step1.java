package com.example.myapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class step1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.step1);

        EditText macc = findViewById(R.id.maccET1);
        EditText mpwd = findViewById(R.id.mpwdET1);
        Button mjoin = findViewById(R.id.mjoingBTN1);
        Button mlogin = findViewById(R.id.mloginBTN1);
        mjoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(step1.this , step2.class);
                startActivity(intent);
            }
        });

        mlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(step1.this , step3.class);
                startActivity(intent);
            }
        });
    }
}